from models import make_model

def get_base_models():
    configs = [
        {"l1_ratio": 0.3, "C": 0.1},
        {"l1_ratio": 0.5, "C": 0.5},
        {"l1_ratio": 0.7, "C": 1.0},
        {"l1_ratio": 1.0, "C": 1.0},  # LASSO
        {"l1_ratio": 0.0, "C": 1.0},  # Ridge
    ]

    return [
        {
            "name": f"Elastic_L{int(cfg['l1_ratio']*100)}_C{int(cfg['C']*10)}",
            "params": cfg
        } for cfg in configs
    ]
